import os
from flask import Flask, render_template, request
import ktrain
from ktrain import text
from sklearn.datasets import fetch_20newsgroups
import requests
import random
remove = ('headers', 'footers', 'quotes')
newsgroups_train = fetch_20newsgroups(subset='train', remove=remove)
newsgroups_test = fetch_20newsgroups(subset='test', remove=remove)

INDEXDIR_COVID = '/tmp/myindex_'+str(random.random())

docs=['Coronaviruses are a large family of viruses which may cause illness in animals or humans.  In humans, several coronaviruses are known to cause respiratory infections ranging from the common cold to more severe diseases such as Middle East Respiratory Syndrome (MERS) and Severe Acute Respiratory Syndrome (SARS).The most recently discovered coronavirus causes coronavirus disease COVID-19.',
'COVID-19 is the infectious disease caused by the most recently discovered coronavirus. This new virus and disease were unknown before the outbreak began in Wuhan, China, in December 2019. COVID-19 is now a pandemic affecting many countries globally.',
'The most common symptoms of COVID-19 are fever, dry cough, and tiredness. Other symptoms that are less common and may affect some patients include aches and pains, nasal congestion, headache, conjunctivitis, sore throat, diarrhea, loss of taste or smell or a rash on skin or discoloration of fingers or toes. These symptoms are usually mild and begin gradually.Some people become infected but only have very mild symptoms.',
'Most people (about 80%) recover from the disease without needing hospital treatment. Around 1 out of every 5 people who gets COVID-19 becomes seriously ill and develops difficulty breathing. Older people, and those with underlying medical problems like high blood pressure, heart and lung problems, diabetes, or cancer, are at higher risk of developing serious illness.  However, anyone can catch COVID-19 and become seriously ill.  People of all ages who experience fever and/or  cough associated withdifficulty breathing/shortness of breath, chest pain/pressure, or loss of speech or movement should seek medical attention immediately.', 
'If possible, it is recommended to call the health care provider or facility first, so the patient can be directed to the right clinic. If you have minor symptoms, such as a slight cough or a mild fever, there is generally no need to seek medical care. Stay at home, self-isolate and monitor your symptoms. Follow national guidance on self-isolation.',
'However, if you live in an area with malaria or dengue fever it is important that you do not ignore symptoms of fever.  Seek medical help.  When you attend the health facility wear a mask if possible',
'keep at least 1 metre distance from other people and do not touch surfaces with your hands. If it is a child who is sick help the child stick to this advice.',
'Seek immediate medical care if you have difficulty breathing or pain/pressure in the chest. If possible, call your health care provider in advance, so he/she can direct you to the right health facility.']


text.SimpleQA.initialize_index(INDEXDIR_COVID)
text.SimpleQA.index_from_list(docs, INDEXDIR_COVID, commit_every=len(docs))

qa = text.SimpleQA(INDEXDIR_COVID)


app = Flask(__name__)



@app.route('/', methods=['GET', 'POST'])
def index():
    text={}
    answers = {}
    result = {}
    #results = {}
    if request.method == "POST":
        
        # get url that the person has entered
        try:
            text = request.form['url']
            answers = qa.ask(text)
            result = answers[0]['full_answer']
            
            #results = qa.display_answers(answers[:5])
    
        except:
            pass 

    return render_template('index.html',results=result)


if __name__ == '__main__':
    app.run()